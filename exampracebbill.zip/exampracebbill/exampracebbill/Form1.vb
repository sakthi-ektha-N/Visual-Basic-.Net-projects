﻿Imports System.Data.Sql
Imports System.Data.SqlClient
Public Class Form1
    Dim con As New SqlConnection
    Dim cmd As New SqlCommand
    Dim consumedunits As New Integer
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EbbillpracDataSet.cus_tbl' table. You can move, or remove it, as needed.
        Me.Cus_tblTableAdapter.Fill(Me.EbbillpracDataSet.cus_tbl)

        con.ConnectionString = "Data Source=laptop-054ffkja\sqlexpress;Initial Catalog=ebbillprac;Integrated Security=True;Pooling=False"
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        MessageBox.Show("connection established")

    End Sub
    Public Sub disp_data()
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select*from cus_tbl"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.ColumnIndex <> 2 Then
            'the try catch statement is used to handle any exception if formed.
            'using the index we select a particular row in the grid view data to undergo insert,update,del,search operation.
            Try
                If con.State = ConnectionState.Open Then
                    con.Close()

                End If
                con.Open()
                Dim i As Integer
                i = e.RowIndex
                Dim selectedrow As DataGridViewRow
                selectedrow = DataGridView1.Rows(i)
                cusid_txt.Text = selectedrow.Cells(0).Value.ToString()
            Catch ex As Exception
            End Try
        Else
            'the try catch statement is used to handle any exception if formed.
            'using the index we select a particular row in the grid view data to undergo insert,update,del,search operation.
            Try
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                Dim i As Integer
                i = e.RowIndex
                Dim selectedrow As DataGridViewRow
                selectedrow = DataGridView1.Rows(i)
                cusid_txt.Text = selectedrow.Cells(0).Value.ToString()
            Catch ex As Exception
            End Try
            Panel1.Visible = True
            cmd = con.CreateCommand()
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select customer_name from cus_tbl where customer_id='" + cusid_txt.Text + "'"
            cmd.ExecuteNonQuery()
            Dim dt As New DataTable()
            Dim da As New SqlDataAdapter(cmd)
            da.Fill(dt)
            If dt.Rows.Count() > 0 Then
                cus_name_txt.Text = dt.Rows(0)(0).ToString()
            Else
                MessageBox.Show("PLease pay your bill !!")
            End If
        End If

    End Sub

    Private Sub displaybtn_Click(sender As System.Object, e As System.EventArgs) Handles displaybtn.Click
        disp_data()
    End Sub

    Private Sub SEARCHBTN_Click(sender As System.Object, e As System.EventArgs) Handles SEARCHBTN.Click
        cmd = con.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from cus_tbl where customer_id='" + cusid_txt.Text + "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New SqlDataAdapter(cmd)
        da.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub Creadingtxt_Leave(sender As Object, e As System.EventArgs) Handles Creadingtxt.Leave
        totalunitstxt.Text = Creadingtxt.Text - Preadingtxt.Text
        consumedunits = totalunitstxt.Text
    End Sub


    Private Sub conn_type_combo_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles conn_type_combo.SelectedIndexChanged
        If conn_type_combo.SelectedIndex = 0 Then
            If consumedunits <= 500 Then
                total_amount_txt.Text = consumedunits * 3
            ElseIf consumedunits > 500 Then
                total_amount_txt.Text = consumedunits * 5

            ElseIf consumedunits > 700 Then
                total_amount_txt.Text = consumedunits * 7
            Else
                total_amount_txt.Text = consumedunits * 10
            End If
        Else
            If consumedunits <= 500 Then
                total_amount_txt.Text = consumedunits * 5
            ElseIf consumedunits > 500 Then
                total_amount_txt.Text = consumedunits * 10
            ElseIf consumedunits > 700 Then
                total_amount_txt.Text = consumedunits * 15
            Else
                total_amount_txt.Text = consumedunits * 20
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Dim cmd As New SqlCommand("insert into bill_tbl values('" + cusid_txt.Text + "','" + cus_name_txt.Text + "','" + Creadingtxt.Text + "','" + Preadingtxt.Text + "','" + totalunitstxt.Text + "','" + conn_type_combo.Text + "','" + total_amount_txt.Text + "')", con)
        cmd.ExecuteNonQuery()
        MsgBox("PAYMENT DONE SUCCESSFULLY!!")
        For i As Integer = 0 To Me.DataGridView1.Rows.Count - 2

            If DataGridView1.Rows(i).Cells(0).Value = cusid_txt.Text Then

                DataGridView1.Rows(i).Cells(2).ReadOnly = True

            End If
        Next
        cus_name_txt.Clear()
        Creadingtxt.Clear()
        Preadingtxt.Clear()
        totalunitstxt.Text = "0"
        conn_type_combo.Text = ""
        total_amount_txt.Text = "0"

    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        cus_name_txt.Clear()
        Creadingtxt.Clear()
        Preadingtxt.Clear()
        totalunitstxt.Text = "0"
        conn_type_combo.Text = ""
        total_amount_txt.Text = "0"
    End Sub
End Class
